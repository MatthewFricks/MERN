
import './App.css';
import Pokemon from './components/Pokemon';
import React, {useState} from 'react';

function App() {
  return (
    <div className="App">
      <h1>Pokemon</h1>
      <Pokemon></Pokemon>
    </div>
  );
}

export default App;
