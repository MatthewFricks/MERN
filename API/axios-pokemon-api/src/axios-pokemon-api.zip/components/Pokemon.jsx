
import React, { useEffect, useState } from 'react';
import axios from 'axios';


const Pokemon = () => {

    const [allPokemon, setAllPokemon] = useState([])


    const click = () => {

        axios.get("https://pokeapi.co/api/v2/pokemon?limit=1000&offset=0")
            .then(res => {
            console.log(res)
            setAllPokemon(res.data)
        })
            .catch(err => {
                console.log(err)
            })

    }
    return (
        <div>
            <button onClick={click} className="btn btn-success">Show Pokemon!</button>
            {
                allPokemon.map((pokes, idx) => {
                    return <div>
                        <h4>{pokes.name}</h4>
                    </div>
                })
            }
        </div>
    );
};






// const Pokemon = () => {

//     const [allPokemon, setAllPokemon] = useState([])

//     const click = () => {
//     fetch("https://pokeapi.co/api/v2/pokemon?limit=1000&offset=0")
//         .then(res=>{
//             return res.json()
//         })
//         .then (res=>{
//             setAllPokemon(res)
//         })
//     }
//     .catch(err=>{
//         console.log(err)
//     })

// }
//     return (
//         <div>
//             <button onClick= {click} className="btn btn-success">Show Pokemon</button>
//             {
//                 allPokemon.map((pokes, index)=>{
//                     return <div style = {{backgroundColor: "gray"}} key = {index} className="card">
//                     <p>{pokes.name}</p>
//                     </div>
//                 })
//             }
//         </div>
//     )
// }

export default Pokemon;

